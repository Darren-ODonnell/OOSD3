Upon opening the programming you will notice 2 menu options, Home and Orders

Home allows you to exit the program where Orders allows you to create a new order

Once an order has been created using the radio buttons, you should proceed to clicking "Order to Chef"

Once clicked, it will bring you to the Order Processing Screen, 
where it will show you how your order is doing through each stage of the process.

Once it is finished a pop-up message will notify you that your order is finished and you may exit or order another meal


I used Restaurant.sleep in a few places inside the waiter and chef threads, 
this allows the user to see the change in state happen as the order is prepared.


The Display Class is a class I have built up over the last couple years. It controls all dialog boxes.